// Gunakan utilitas dari face-swap-utils.js
async function performSwap() {
    showLoading('Memproses swap wajah...');
    try {
        // ... deteksi wajah seperti sebelumnya
        // Setelah mendapatkan sourceFaceCanvas dan targetRect
        // Lakukan color correction
        colorCorrection(sourceCtx, templateCtx, sourceRect, targetRect);
        // Gambar dengan blending
        ctx.drawImage(sourceCanvas, targetRect.x, targetRect.y, targetRect.width, targetRect.height);
        // Terapkan feathering
        applyFeathering(ctx, targetRect.x, targetRect.y, targetRect.width, targetRect.height, 15);
        // ... sisanya sama
    } catch(e) { ... }
}