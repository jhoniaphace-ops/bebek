// Utilitas untuk color correction dan feathering
function colorCorrection(sourceCtx, targetCtx, sourceRect, targetRect) {
    // Implementasi histogram matching sederhana
    // Ambil rata-rata RGB dari source dan target, lalu adjust
    const sourceData = sourceCtx.getImageData(sourceRect.x, sourceRect.y, sourceRect.width, sourceRect.height);
    const targetData = targetCtx.getImageData(targetRect.x, targetRect.y, targetRect.width, targetRect.height);
    
    let srcR=0, srcG=0, srcB=0, srcCount=0;
    for(let i=0; i<sourceData.data.length; i+=4) {
        srcR += sourceData.data[i];
        srcG += sourceData.data[i+1];
        srcB += sourceData.data[i+2];
        srcCount++;
    }
    srcR /= srcCount; srcG /= srcCount; srcB /= srcCount;
    
    let tgtR=0, tgtG=0, tgtB=0, tgtCount=0;
    for(let i=0; i<targetData.data.length; i+=4) {
        tgtR += targetData.data[i];
        tgtG += targetData.data[i+1];
        tgtB += targetData.data[i+2];
        tgtCount++;
    }
    tgtR /= tgtCount; tgtG /= tgtCount; tgtB /= tgtCount;
    
    const scaleR = tgtR / (srcR + 0.001);
    const scaleG = tgtG / (srcG + 0.001);
    const scaleB = tgtB / (srcB + 0.001);
    
    for(let i=0; i<sourceData.data.length; i+=4) {
        sourceData.data[i] = Math.min(255, sourceData.data[i] * scaleR);
        sourceData.data[i+1] = Math.min(255, sourceData.data[i+1] * scaleG);
        sourceData.data[i+2] = Math.min(255, sourceData.data[i+2] * scaleB);
    }
    sourceCtx.putImageData(sourceData, sourceRect.x, sourceRect.y);
}

function applyFeathering(ctx, x, y, width, height, featherAmount = 20) {
    ctx.save();
    ctx.globalCompositeOperation = 'destination-in';
    ctx.beginPath();
    const gradient = ctx.createRadialGradient(x+width/2, y+height/2, Math.min(width,height)/2 - featherAmount, x+width/2, y+height/2, Math.min(width,height)/2);
    gradient.addColorStop(0, 'rgba(255,255,255,1)');
    gradient.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = gradient;
    ctx.fillRect(x, y, width, height);
    ctx.restore();
}

// Expression tracking (smile, eye blink)
async function detectExpression(faceImage) {
    const detections = await faceapi.detectSingleFace(faceImage, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks();
    if (!detections) return null;
    
    const landmarks = detections.landmarks;
    // Smile detection: rasio lebar mulut terhadap tinggi
    const mouth = landmarks.getMouth();
    const mouthWidth = Math.hypot(mouth[12].x - mouth[0].x, mouth[12].y - mouth[0].y);
    const mouthHeight = Math.hypot(mouth[6].x - mouth[3].x, mouth[6].y - mouth[3].y);
    const smileRatio = mouthWidth / (mouthHeight + 0.001);
    
    // Eye blink detection (EAR)
    const leftEye = landmarks.getLeftEye();
    const rightEye = landmarks.getRightEye();
    const ear = (eyeAspectRatio(leftEye) + eyeAspectRatio(rightEye)) / 2;
    
    return { smile: smileRatio > 1.8, blink: ear < 0.2, smileIntensity: Math.min(1, (smileRatio-1)/1.5) };
}

function eyeAspectRatio(eye) {
    const p1 = eye[1], p2 = eye[5], p3 = eye[2], p4 = eye[4];
    const vert = Math.hypot(p1.x-p2.x, p1.y-p2.y);
    const hor = Math.hypot(p3.x-p4.x, p3.y-p4.y);
    return vert / (hor + 0.001);
}

// Simulasi FOMM: warp affine berdasarkan ekspresi
function applyExpressionToTarget(targetCtx, targetRect, expression, intensity = 0.5) {
    // Jika senyum, sedikit melengkungkan sudut bibir pada target
    if (expression && expression.smile) {
        // Transformasi sederhana: geser titik landmark mulut
        // Implementasi lebih lanjut bisa menggunakan mesh warp
        console.log('Smile detected, applying warp');
    }
}