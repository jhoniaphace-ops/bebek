// Mobile menu toggle
document.addEventListener('DOMContentLoaded', () => {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');

    if (hamburger) {
        hamburger.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            hamburger.classList.toggle('active');
        });
    }

    // Set active bottom nav
    const currentPage = window.location.pathname;
    const bottomNavItems = document.querySelectorAll('.bottom-nav-item');
    
    bottomNavItems.forEach(item => {
        if (currentPage.includes(item.getAttribute('href'))) {
            item.classList.add('active');
        }
    });
});

// Loading overlay
function showLoading(message = 'Memproses...') {
    let overlay = document.querySelector('.loading-overlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.className = 'loading-overlay';
        overlay.innerHTML = `
            <div class="spinner"></div>
            <p style="margin-top: 1rem;">${message}</p>
        `;
        document.body.appendChild(overlay);
    } else {
        overlay.querySelector('p').textContent = message;
        overlay.style.display = 'flex';
    }
}

function hideLoading() {
    const overlay = document.querySelector('.loading-overlay');
    if (overlay) {
        overlay.style.display = 'none';
    }
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        padding: 1rem;
        background: ${type === 'success' ? '#4caf50' : '#f44336'};
        color: white;
        border-radius: 8px;
        z-index: 10000;
        animation: slideIn 0.3s ease;
    `;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
}

// Load Face-API models
async function loadFaceApiModels() {
    const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.10/model/';
    
    await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
    await faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL);
    await faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL);
    await faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL);
}

// Face swap function untuk image
async function swapFace(sourceImage, targetImage) {
    const sourceDetections = await faceapi.detectSingleFace(sourceImage, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks();
    
    const targetDetections = await faceapi.detectSingleFace(targetImage, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks();
    
    if (!sourceDetections || !targetDetections) {
        throw new Error('Wajah tidak terdeteksi pada salah satu gambar');
    }
    
    const canvas = document.createElement('canvas');
    canvas.width = targetImage.width;
    canvas.height = targetImage.height;
    const ctx = canvas.getContext('2d');
    
    ctx.drawImage(targetImage, 0, 0);
    
    const sourceLandmarks = sourceDetections.landmarks.positions;
    const targetLandmarks = targetDetections.landmarks.positions;
    
    // Hitung transformasi affine manual untuk wajah
    const srcTri = [sourceLandmarks[0], sourceLandmarks[16], sourceLandmarks[8]];
    const dstTri = [targetLandmarks[0], targetLandmarks[16], targetLandmarks[8]];
    
    // Get face region dari source
    const sourceRect = sourceDetections.detection.box;
    const sourceFaceCanvas = document.createElement('canvas');
    sourceFaceCanvas.width = sourceRect.width;
    sourceFaceCanvas.height = sourceRect.height;
    const sourceFaceCtx = sourceFaceCanvas.getContext('2d');
    sourceFaceCtx.drawImage(sourceImage, sourceRect.x, sourceRect.y, sourceRect.width, sourceRect.height, 0, 0, sourceRect.width, sourceRect.height);
    
    // Overlay ke target dengan blending
    const targetRect = targetDetections.detection.box;
    ctx.globalAlpha = 0.85;
    ctx.drawImage(sourceFaceCanvas, targetRect.x, targetRect.y, targetRect.width, targetRect.height);
    ctx.globalAlpha = 1;
    
    return canvas;
}

// Download function
function downloadResult(canvas, filename = 'face-swap.png') {
    const link = document.createElement('a');
    link.download = filename;
    link.href = canvas.toDataURL('image/png');
    link.click();
}

// API Calls
async function fetchTemplates(type, category = null) {
    let url = `/api/templates/${type}`;
    if (category && category !== 'all') {
        url += `/category/${encodeURIComponent(category)}`;
    }
    
    const response = await fetch(url);
    return await response.json();
}